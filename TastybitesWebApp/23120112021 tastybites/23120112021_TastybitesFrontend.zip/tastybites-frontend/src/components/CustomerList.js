
import React from 'react';

function CustomerList({ customers, onEdit, onDelete }) {
  return (
    <div className="customer-list">
      {customers.map(customer => (
        <div key={customer._id} className="customer-card">
          <div className="customer-info">
            <h3>{customer.firstName} {customer.surname}</h3>
            <p>Registered on: {new Date(customer.dateOfRegistration).toLocaleDateString()}</p>
          </div>
          <div className="customer-actions">
            <button onClick={() => onEdit(customer)} className="btn btn-edit">Edit</button>
            <button onClick={() => onDelete(customer._id,  `${customer.firstName} ${customer.surname}`)} className="btn btn-delete">Delete</button>
          </div>
        </div>
      ))}


    </div>
    
  );
}

export default CustomerList;