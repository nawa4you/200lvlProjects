



import React, { useState, useEffect } from 'react';


function CustomerForm({ customer, onSave, onCancel, onViewOrders }) {
  const [formData, setFormData] = useState({
    // Initialize state with all the required fields
    firstName: '',
    surname: '',
    middleName: '',
    dateOfBirth: '',
    homeAddress: '',
    dateOfRegistration: '',
    developerMatriculationId: false,

  });

  useEffect(() => {

    if (customer) {
      setFormData({
        firstName: customer.firstName || '',
        surname: customer.surname || '',
        middleName: customer.middleName || '',
        
        dateOfBirth: customer.dateOfBirth ? new Date(customer.dateOfBirth).toISOString().split('T')[0] : '',
        homeAddress: customer.homeAddress || '',
        dateOfRegistration: customer.dateOfRegistration ? new Date(customer.dateOfRegistration).toISOString().split('T')[0] : '',
        developerMatriculationId: customer.developerMatriculationId || false,
      });
    }
  }, [customer]);

  const handleChange = (e) => {
    const { name, value, type, checked } = e.target;
    // Handle checkboxes differently from text inputs
    const newValue = type === 'checkbox' ? checked : value;
    setFormData(prevData => ({ ...prevData, [name]: newValue }));
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    onSave(formData);
  };

  return (
    <form onSubmit={handleSubmit} className="customer-form">
      <h2>{customer ? 'Edit Customer' : 'Add New Customer'}</h2>

      {/* --- Customer Profile Fields --- */}
      <div className="form-group">
        <label>First Name</label>
        <input type="text" name="firstName" value={formData.firstName} onChange={handleChange} required />
      </div>
      <div className="form-group">
        <label>Surname</label>
        <input type="text" name="surname" value={formData.surname} onChange={handleChange} required />
      </div>
      <div className="form-group">
        <label>Middle Name (Optional)</label>
        <input type="text" name="middleName" value={formData.middleName} onChange={handleChange} />
      </div>
      <div className="form-group">
        <label>Date of Birth</label>
        <input type="date" name="dateOfBirth" value={formData.dateOfBirth} onChange={handleChange} />
      </div>
      <div className="form-group">
        <label>Home Address</label>
        <input type="text" name="homeAddress" value={formData.homeAddress} onChange={handleChange} />
      </div>
      <div className="form-group">
        <label>Date of Registration</label>
        <input type="date" name="dateOfRegistration" value={formData.dateOfRegistration} onChange={handleChange} />
      </div>
      <div className="form-group-checkbox">
        <label>Developer?</label>
        <input type="checkbox" name="developerMatriculationId" checked={formData.developerMatriculationId} onChange={handleChange} />
      </div>

      {/* The form actions */}
      {/* The "View Orders" button only shows when editing an existing customer */}
        {customer && (
          <button 
            type="button" 
            onClick={() => onViewOrders(customer)} 
            className="btn btn-view-orders"
          >
            View Orders
          </button>
        )}
      <div className="form-actions">
        <button type="submit" className="btn">Save Customer</button>
        <button type="button" onClick={onCancel} className="btn btn-cancel">Cancel</button>
      </div>
    </form>
  );
}

export default CustomerForm;
