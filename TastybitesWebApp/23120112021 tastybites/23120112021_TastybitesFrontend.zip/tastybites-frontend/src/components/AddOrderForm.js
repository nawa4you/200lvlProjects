/*
  File 1: Create a New Component `src/components/AddOrderForm.js`
  -----------------------------------------------------------------
  This is a new form specifically for adding a single order.
*/
import React, { useState } from 'react';

function AddOrderForm({ onSave, onCancel }) {
  const [orderData, setOrderData] = useState({
    orderDate: new Date().toISOString().split('T')[0], // Default to today
    menuItemOrdered: '',
    paymentMethod: 'Card',
  });

  const handleChange = (e) => {
    const { name, value } = e.target;
    setOrderData(prev => ({ ...prev, [name]: value }));
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    onSave(orderData);
  };

  return (
    <form onSubmit={handleSubmit} className="add-order-form">
      <h3 className="add-order-title">Add New Order</h3>
      <div className="form-group">
        <label>Order Date</label>
        <input type="date" name="orderDate" value={orderData.orderDate} onChange={handleChange} required />
      </div>
      <div className="form-group">
        <label>Menu Item</label>
        <input type="text" name="menuItemOrdered" value={orderData.menuItemOrdered} onChange={handleChange} placeholder="e.g., Jollof Rice" required />
      </div>
      <div className="form-group">
        <label>Payment Method</label>
        <input type="text" name="paymentMethod" value={orderData.paymentMethod} onChange={handleChange} required />
      </div>
      <div className="form-actions">
        <button type="submit" className="btn">Save Order</button>
        <button type="button" onClick={onCancel} className="btn btn-cancel">Cancel</button>
      </div>
    </form>
  );
}

export default AddOrderForm;