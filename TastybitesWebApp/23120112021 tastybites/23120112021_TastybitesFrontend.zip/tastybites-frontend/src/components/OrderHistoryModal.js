
import React, { useState } from 'react';
import AddOrderForm from './AddOrderForm'; 

function OrderHistoryModal({ customer, onClose, onAddOrder }) {
 
  const [isAddingOrder, setIsAddingOrder] = useState(false);

  const handleSaveOrder = (orderData) => {
    onAddOrder(customer._id, orderData);
    setIsAddingOrder(false); // Hide form after saving
  };
  
  // This early return is perfectly fine as long as all hooks are called before it.
  if (!customer) {
    return null; // If no customer is selected, don't render the modal
  }

  return (
    <div className="modal-overlay">
      <div className="modal-content">
        <div className="modal-header">
          <h2 className="modal-title">Order History for {customer.firstName} {customer.surname}</h2>
          {/* Show "Add Order" button if not already adding */}
          {!isAddingOrder && (
            <button onClick={() => setIsAddingOrder(true)} className="btn btn-add-order">Add New Order</button>
          )}
        </div>

        {isAddingOrder ? (
          <AddOrderForm onSave={handleSaveOrder} onCancel={() => setIsAddingOrder(false)} />
        ) : (
          <>
            {(!customer.orders || customer.orders.length === 0) ? (
              <p>This customer has no order history.</p>
            ) : (
              <div className="order-list">
                <table>
                  <thead>
                    <tr>
                      <th>Order Date</th>
                      <th>Menu Item</th>
                      <th>Payment Method</th>
                    </tr>
                  </thead>
                  <tbody>
                    {customer.orders.map((order, index) => (
                      <tr key={index}>
                        <td>{new Date(order.orderDate).toLocaleDateString()}</td>
                        <td>{order.menuItemOrdered}</td>
                        <td>{order.paymentMethod}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}
          </>
        )}
        
        <button onClick={onClose} className="btn btn-close">Close</button>
      </div>
    </div>
  );
}

export default OrderHistoryModal;

