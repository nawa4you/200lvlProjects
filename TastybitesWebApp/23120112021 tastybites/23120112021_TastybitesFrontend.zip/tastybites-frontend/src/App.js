// src/App.js
import React, { useState, useEffect } from 'react';
import axios from 'axios';
import CustomerList from './components/CustomerList';
import CustomerForm from './components/CustomerForm';
import OrderHistoryModal from './components/OrderHistoryModal';
import './App.css'; // theme

function App() {
  const [customers, setCustomers] = useState([]);
  const [selectedCustomer, setSelectedCustomer] = useState(null);
  const [isFormVisible, setIsFormVisible] = useState(false);
  const [viewingOrdersFor, setViewingOrdersFor] = useState(null);

    const handleViewOrders = (customer) => {
    setViewingOrdersFor(customer);
  };

  
  const handleCloseOrders = () => {
    setViewingOrdersFor(null);
  };


  
  // adding order (handler)
  const handleAddOrder = async (customerId, orderData) => {
    try {
      // The POST request now returns the updated customer data.
      const response = await axios.post(`/api/customers/${customerId}/orders`, orderData);
      const updatedCustomer = response.data;

      // update the state for the modal immediately.
      setViewingOrdersFor(updatedCustomer);

      // updt customer list state to ensure consistency.
      setCustomers(prevCustomers => 
        prevCustomers.map(c => (c._id === customerId ? updatedCustomer : c))
      );

    } catch (error) {
      console.error('Error adding new order:', error);
    }
  };





  // READ: Fetch all customers when the app loads
  useEffect(() => {
    fetchCustomers();
  }, []);

  const fetchCustomers = async () => {
    try {
      const response = await axios.get('/api/customers');
      setCustomers(response.data);
    } catch (error) {
      console.error('Error fetching customers:', error);
    }
  };

  // CREATE / UPDATE


//...
  const handleSave = async (customerData) => {
    console.log('Step 2: App component received data:', customerData);
    try {
      let response;
      if (selectedCustomer) {
        console.log('Step 3: Attempting to UPDATE customer...'); 
        response = await axios.patch(`/api/customers/${selectedCustomer._id}`, customerData);
      } else {
        console.log('Step 3: Attempting to CREATE customer...'); 
        response = await axios.post('/api/customers', customerData);
      }
      console.log('Step 4: API call successful! Response:', response.data);

      fetchCustomers();
      setIsFormVisible(false);
      setSelectedCustomer(null);
    } catch (error) {
      // THIS WILL CATCH ANY AND ALL ERRORS FROM THE API CALL
      console.error('--- API CALL FAILED ---'); 
      console.error(error.response ? error.response.data : error.message);
    }
  };


      // DELETE with confirmation
  const handleDelete = async (customerId, customerName) => {
    
    const isConfirmed = window.confirm(`Are you sure you want to delete ${customerName}?`);

   
    if (isConfirmed) {
      try {
        await axios.delete(`/api/customers/${customerId}`);
        fetchCustomers();
      } catch (error) {
        console.error('Error deleting customer:', error);
      }
    }
  };
  

  const handleEdit = (customer) => {
    setSelectedCustomer(customer);
    setIsFormVisible(true);
  };

  const handleAddNew = () => {
    setSelectedCustomer(null);
    setIsFormVisible(true);
  };
  
  const handleCancel = () => {
    setIsFormVisible(false);
    setSelectedCustomer(null);
  }

   return (
    <div className="app-container">
      {/* Conditionally render the modal when 'viewingOrdersFor' has a customer */}
      {viewingOrdersFor && (
        <OrderHistoryModal
          customer={viewingOrdersFor}
          onClose={handleCloseOrders}
          onAddOrder={handleAddOrder}
        />
      )}
      <header className="app-header">
        {/* Logo and title */}
        <img src="./logo.png" alt="TastyBites Logo" className="app-logo" />
        <h1>TastyBites Customer Management</h1>
      </header>
      
      {/*  acrylic effect */}
      <div className="card">
        {isFormVisible ? (
          <CustomerForm 
            customer={selectedCustomer} 
            onSave={handleSave} 
            onCancel={handleCancel}
            onViewOrders={handleViewOrders} 
          />
        ) : (
          <>
            <button onClick={handleAddNew} className="btn add-new-btn">Add New Customer</button>
            <CustomerList 
              customers={customers} 
              onEdit={handleEdit} 
              onDelete={handleDelete} 
            />
          </>
        )}
      </div>

    </div>
  );

    

}

export default App;