
import { 
  IsString, 
  IsDateString, 
  IsBoolean, 
  IsOptional, 
  IsArray, 
  IsNotEmpty 
} from 'class-validator';


export class CustomerDto {
  @IsString()
  @IsNotEmpty()
  firstName: string;

  @IsString()
  @IsNotEmpty()
  surname: string;

  @IsString()
  @IsOptional()
  middleName?: string;

  @IsDateString()
  @IsOptional()
  dateOfBirth?: string;

  @IsString()
  @IsOptional()
  homeAddress?: string;

  @IsDateString()
  @IsOptional()
  dateOfRegistration?: string;

  @IsBoolean()
  @IsOptional()
  developerMatriculationId?: boolean;


  @IsArray()
  @IsOptional()
  orders?: any[];
}
