
import { Injectable, NotFoundException } from '@nestjs/common';
import { InjectModel } from '@nestjs/mongoose';
import { Model } from 'mongoose';
import { Customer, Order } from './schemas/customer.schema';
import { CustomerDto } from './dto/customer.dto'; // Import the correct DTO

@Injectable()
export class CustomersService {
  constructor(@InjectModel(Customer.name) private customerModel: Model<Customer>) {}

  // CREATE a new customer using the correct DTO
  async create(customerDto: CustomerDto): Promise<Customer> {
    console.log('Creating customer with data:', customerDto);
    const newCustomer = new this.customerModel(customerDto);
    try {
        const savedCustomer = await newCustomer.save();
        return savedCustomer;
    } catch (error) {
        console.error("Error saving customer:", error);
        throw error;
    }
  }

  // READ all customers
  async findAll(): Promise<Customer[]> {
    return this.customerModel.find().exec();
  }

  // READ a single customer by ID
  async findOne(id: string): Promise<Customer> {
    const customer = await this.customerModel.findById(id).exec();
    if (!customer) {
      throw new NotFoundException(`Customer with ID "${id}" not found`);
    }
    return customer;
  }

  // UPDATE a customer by ID using the correct DTO
  async update(id: string, customerDto: CustomerDto): Promise<Customer> {
    const existingCustomer = await this.customerModel.findByIdAndUpdate(id, customerDto, { new: true }).exec();
    if (!existingCustomer) {
      throw new NotFoundException(`Customer with ID "${id}" not found`);
    }
    return existingCustomer;
  }

  // DELETE a customer by ID
  async remove(id: string): Promise<Customer> {
    const deletedCustomer = await this.customerModel.findByIdAndDelete(id);
    if (!deletedCustomer) {
      throw new NotFoundException(`Customer with ID "${id}" not found`);
    }
    return deletedCustomer;
  }


  // Add an order to an existing customer
  async addOrder(customerId: string, orderData: Order): Promise<Customer> {
    const customer = await this.customerModel.findByIdAndUpdate(
      customerId,
      { $push: { orders: orderData } }, //  $push to add the new order to the orders array
      { new: true } // Return the updated doc
    ).exec();

    if (!customer) {
      throw new NotFoundException(`Customer with ID "${customerId}" not found`);
    }
    return customer;
  }
}
