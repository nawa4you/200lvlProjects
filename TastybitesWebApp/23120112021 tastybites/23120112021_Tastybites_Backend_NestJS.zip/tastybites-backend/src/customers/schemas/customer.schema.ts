import { Prop, Schema, SchemaFactory } from '@nestjs/mongoose';
import { Document } from 'mongoose';

@Schema({ timestamps: true })
//not using this 
export class Order extends Document {
  @Prop()
  orderDate: Date; // 

  @Prop({ required: true })
  menuItemOrdered: string; // 

  @Prop()
  specialInstructions: string; // 

  @Prop()
  paymentMethod: string;

  @Prop()
  nextReservationDate: Date; // 
}
export const OrderSchema = SchemaFactory.createForClass(Order);


@Schema({ timestamps: true })
export class Customer extends Document {
  @Prop({ required: true })
  firstName: string; // 

  @Prop({ required: true })
  surname: string; // 

  @Prop()
  middleName: string; // 

  @Prop()
  dateOfBirth: Date; // 

  @Prop()
  homeAddress: string; // 

  @Prop({ default: Date.now })
  dateOfRegistration: Date; // 

  @Prop()
  developerMatriculationId: boolean; // 

  @Prop({ type: [OrderSchema], default: [] })
  orders: Order[];
}

export const CustomerSchema = SchemaFactory.createForClass(Customer);