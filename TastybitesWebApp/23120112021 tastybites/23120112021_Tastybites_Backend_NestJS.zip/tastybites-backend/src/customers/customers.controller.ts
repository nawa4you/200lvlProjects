
import { Controller, Get, Post, Body, Param, Delete, Patch } from '@nestjs/common';
import { CustomersService } from './customers.service';
import { Order } from './schemas/customer.schema';

@Controller('customers') // Base path
export class CustomersController {
  constructor(private readonly customersService: CustomersService) {}

  @Post() // POST /customers
  create(@Body() createCustomerDto: any) {
    return this.customersService.create(createCustomerDto);
  }

  @Get() // GET /customers
  findAll() {
    return this.customersService.findAll();
  }

  @Get(':id') // GET /customers/:id
  findOne(@Param('id') id: string) {
    return this.customersService.findOne(id);
  }

  @Patch(':id') // PATCH /customers/:id
  update(@Param('id') id: string, @Body() updateCustomerDto: any) {
    return this.customersService.update(id, updateCustomerDto);
  }

  @Delete(':id') // DELETE /customers/:id
  remove(@Param('id') id: string) {
    return this.customersService.remove(id);
  }


   // handles POST requests to /customers/:id/orders
  @Post(':id/orders')
  addOrder(@Param('id') customerId: string, @Body() orderData: Order) {
    return this.customersService.addOrder(customerId, orderData);
  }
}